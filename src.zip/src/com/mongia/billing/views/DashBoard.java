package com.mongia.billing.views;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class DashBoard extends JFrame {

	private JPanel contentPane;

	
	public DashBoard(String userid) {
		setTitle("Welcome "+userid);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1077, 736);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JMenuBar menuBar = new JMenuBar();
		this.setJMenuBar(menuBar);
		
		JMenu mnAdmin = new JMenu("Admin");
		menuBar.add(mnAdmin);
		
		JMenu mnProducts = new JMenu("Products");
		mnAdmin.add(mnProducts);
		
		JMenuItem mntmAddProduct = new JMenuItem("Add Product");
		mnProducts.add(mntmAddProduct);
		
		JMenuItem mntmUpdateProduct = new JMenuItem("Update Product");
		mnProducts.add(mntmUpdateProduct);
		
		JMenuItem mntmDeleteProduct = new JMenuItem("Delete Product");
		mnProducts.add(mntmDeleteProduct);
		
		JMenuItem mntmCustomerReport = new JMenuItem("Customer Report");
		mnAdmin.add(mntmCustomerReport);
		
		JMenu mnOrder = new JMenu("Order");
		menuBar.add(mnOrder);
		
		JMenuItem mntmOrderPlace = new JMenuItem("Order Place");
		mnOrder.add(mntmOrderPlace);
		
		JMenuItem mntmTrack = new JMenuItem("Track");
		mnOrder.add(mntmTrack);
		//menuBar.setBounds(75, 10, 101, 22);
		//contentPane.add(menuBar);
	}
}
